package com.amrita.sampledonorapp.service;

import java.util.List;

import com.amrita.sampledonorapp.bean.DonorBean;
import com.amrita.sampledonorapp.exception.DonorException;

public interface IDonorService {
	public String addDonorDetails(DonorBean donor) throws DonorException;
	public DonorBean viewDonorDetails(String donorId) throws DonorException;
	public List<DonorBean> retriveAll()throws DonorException;

}
