package com.amrita.sampledonorapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.amrita.sampledonorapp.bean.DonorBean;
import com.amrita.sampledonorapp.exception.DonorException;
import com.amrita.sampledonorapp.dao.QueryMapper;
import com.amrita.sampledonorapp.util.DBConnection;

public class DonorDaoImpl implements IDonorDao {

	@Override
	public String addDonorDetails(DonorBean donor) throws DonorException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String donorId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,donor.getDonorName());			
			preparedStatement.setString(2,donor.getAddress());
			preparedStatement.setString(3,donor.getPhoneNumber());
			preparedStatement.setDouble(4,donor.getDonationAmount());			
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.DONARID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				donorId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				throw new DonorException("Inserting donor details failed ");

			}
			else
			{
				return donorId;
			}

		}
		catch(SQLException sqlException)
		{
			throw new DonorException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new DonorException("Error in closing db connection");

			}
		}
	}

	@Override
	public DonorBean viewDonorDetails(String donorId) throws DonorException {
		// TODO Auto-generated method stub
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		DonorBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_DONAR_DETAILS_QUERY);
			preparedStatement.setString(1,donorId);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new DonorBean();
				bean.setDonorName(resultset.getString(1));
				bean.setAddress(resultset.getString(2));
				bean.setPhoneNumber(resultset.getString(3));
				bean.setDonationDate(resultset.getDate(4));
				bean.setDonationAmount(resultset.getDouble(5));
				
			}
			
			if( bean != null)
			{
				return bean;
			}
			else
			{
				return null;
			}
			
		}
		catch(Exception e)
		{
			throw new DonorException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				throw new DonorException("Error in closing db connection");

			}
		}
	}

	@Override
	public List<DonorBean> retriveAllDetails() throws DonorException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		int donorCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<DonorBean> donorList=new ArrayList<DonorBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				DonorBean bean=new DonorBean();
				bean.setDonorName(resultset.getString(1));
				bean.setAddress(resultset.getString(2));
				bean.setPhoneNumber(resultset.getString(3));
				bean.setDonationDate(resultset.getDate(4));
				bean.setDonationAmount(resultset.getDouble(5));
				donorList.add(bean);
				
				donorCount++;
			}			
			
		} catch (SQLException sqlException) {
			throw new DonorException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new DonorException("Error in closing db connection");

			}
		}
		
		if( donorCount == 0)
			return null;
		else
			return donorList;
	}

}
