package com.amrita.sampledonorapp.dao;

import java.util.List;

import com.amrita.sampledonorapp.bean.DonorBean;
import com.amrita.sampledonorapp.exception.DonorException;

public interface IDonorDao {
	public String addDonorDetails(DonorBean donor) throws DonorException;
	public DonorBean viewDonorDetails(String donorId) throws DonorException;
	public List<DonorBean> retriveAllDetails()throws DonorException;

}
